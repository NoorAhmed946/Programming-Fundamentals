#include <iostream>
using namespace std ;
int main() {
system("color 46");
cout << " My name is Noor Ahmed " ;

       
  } 
