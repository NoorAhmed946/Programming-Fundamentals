#include <iostream> 
using namespace std ;
int main () 
{
cout << "        /\\          " <<endl ; 
cout << "     __/~~\\__         " <<endl ; 
cout << "    /  |  |  \\ " <<endl ; 
cout << "   ====.  .====              " <<endl ;  
cout << "       ||||               " <<endl ;



} 