#include<iostream> 
using namespace std ; 
int main() 
{   
cout<< "      ';-.         ___,                 " <<endl;
cout<< "        , ,       /' -''        "<<endl ;
cout<< "         . !_...._              "<<endl ;
cout<< "          !        /      ,',_   " <<endl;
cout<< "          /()   () !     .    ._  "<<endl;
cout<< "         |)  .    ()!   /   _.     "<<endl ;
cout<< "          |  -'-     ,;  '. <     "<<endl ;
cout<< "          ;.__     ,;|    > |     "<<endl ;
cout<< "         / ,    / ,  |.-'.-       " <<endl;
cout<< "        (_/    (_/ ,;|.<'          "<<endl;
cout<< "          !    ,     ;-'       " <<endl;
cout<< "           >   !    /       " <<endl;
cout<< "          (_,-''> .'   "<<endl ;
cout<< "            (_,'         "<<endl ;     

  }

