#include<iostream> 
using namespace std ; 
int main() 
{   
cout <<"    +--^---------,-------,------,--------^--,   "<<endl ;
cout <<"     | |||||||||  '_______'      |           o "<<endl;
cout <<"     '+--------------------------^-----------|"<<endl;  
cout <<"       ',--------,-------,-----------------'  "<<endl;
cout <<"         / XXXXX  /'|     /'  "<<endl ;
cout <<"        / XXXXX  /  |    /'   "<<endl ;
cout <<"       / XXXXX  /'------'     "<<endl ;
cout <<"      / XXXXX  /   " <<endl; 
cout <<"     / XXXXX  /  " <<endl ; 
cout <<"    (________(  "<<endl ;
cout <<"     '______'   "<<endl ;          

  }

